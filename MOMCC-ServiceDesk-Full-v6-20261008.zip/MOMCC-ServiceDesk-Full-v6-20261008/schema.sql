-- Reference schema; the application creates these tables at first startup.


CREATE TABLE users (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(100) NOT NULL, 
	email VARCHAR(180) NOT NULL, 
	password VARCHAR(200) NOT NULL, 
	`role` VARCHAR(20) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (email)
)

;


CREATE TABLE sessions (
	token VARCHAR(64) NOT NULL, 
	user_id INTEGER NOT NULL, 
	expires DATETIME NOT NULL, 
	PRIMARY KEY (token), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)

;


CREATE TABLE tickets (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	title VARCHAR(200) NOT NULL, 
	description TEXT NOT NULL, 
	category VARCHAR(80) NOT NULL, 
	location VARCHAR(100) NOT NULL, 
	domain VARCHAR(100) NOT NULL, 
	severity VARCHAR(20) NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	requester_id INTEGER NOT NULL, 
	assignee_id INTEGER, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	first_response_at DATETIME, 
	resolved_at DATETIME, 
	closed_at DATETIME, 
	resolution TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(requester_id) REFERENCES users (id), 
	FOREIGN KEY(assignee_id) REFERENCES users (id)
)

;


CREATE TABLE entries (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	ticket_id INTEGER NOT NULL, 
	user_id INTEGER, 
	kind VARCHAR(20) NOT NULL, 
	text TEXT NOT NULL, 
	minutes INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(ticket_id) REFERENCES tickets (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)

;


CREATE TABLE notifications (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	ticket_id INTEGER NOT NULL, 
	text VARCHAR(255) NOT NULL, 
	created_at DATETIME, 
	read_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(ticket_id) REFERENCES tickets (id)
)

;

