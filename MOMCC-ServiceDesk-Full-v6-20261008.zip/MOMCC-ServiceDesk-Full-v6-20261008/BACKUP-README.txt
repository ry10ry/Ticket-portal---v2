MOMCC ServiceDesk 完整项目备份 — v6 — 2026-10-08

依据你确认正在使用的v6制作，不含v7/v8隐藏Pending Customer的改动。
包含完整Python应用、前端、依赖、Dockerfile、Compose、schema参考、测试、HTTPS脚本及.env.example。app的四个更新文件直接来自已交付的v6 ZIP。

这份是项目源代码和部署模板备份，不是你Windows服务器的运行数据快照。
实际MySQL数据、用户账号及工单记录、上传附件、你修改过的.env与Compose、已生成SSL证书/密钥和portal-ip.txt需在原服务器另存。

原服务器另外备份步骤（项目文件夹PowerShell）：
1. 将原项目整个文件夹复制到安全备份目录，包含你现有.env、Compose和ssl文件夹。这可保留实际密码/IP/证书。
2. 数据库导出，以下命令不在PowerShell输出数据库内容：
docker compose exec -T db sh -c 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysqldump -u root --single-transaction --routines --triggers --events --no-tablespaces --set-gtid-purged=OFF "$MYSQL_DATABASE" > /tmp/momcc-backup.sql'
确认成功后执行：
docker compose cp db:/tmp/momcc-backup.sql .\momcc-backup.sql
3. 附件备份：
docker compose cp web:/data/attachments .\attachments-backup
4. 保存SQL、附件、实际项目文件夹到你的备份位置。证书私钥和.env包含敏感资料，请作为内部备份保管。
如果导出或复制失败，不要当作备份成功，先检查命令报错。备份期间暂停新增/修改工单可避免SQL和附件不一致。

恢复已有服务器代码：备份原文件后覆盖app代码，保留现有.env、Compose、ssl，不要删除Docker数据卷。
HTTPS重新构建与启动：
docker compose build web scheduler
powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-HTTPS.ps1

新服务器从零搭建：参考README.md及Setup-Guide.txt，先依据.env.example填写实际.env。新环境不会自带旧工单，需要单独恢复SQL和附件；SSL可恢复原ssl文件夹，IP改变时按HTTPS指南重签。
不要使用docker compose down -v，它会删除数据卷。
