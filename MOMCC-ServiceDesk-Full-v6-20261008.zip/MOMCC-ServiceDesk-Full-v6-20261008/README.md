# MOMCC ServiceDesk — 故障报修网站

Python FastAPI + SQLAlchemy + MySQL，前端 HTML/CSS/JavaScript。Express 属于 Node.js 框架；本版本选择 Python FastAPI，不同时运行 Express。

参考提供的 Requester / Infra SOP 和 Workflow Diagram。英文界面适用于 TM/TL、Infra Technician 和 Administrator。

## 启动（Windows Docker Desktop 或 Linux Docker Compose）

1. 解压后进入 `momcc-servicedesk` 文件夹。
2. 将 `.env.example` 复制为 `.env`，修改所有密码和 `ADMIN_EMAIL`。管理员密码至少 12 字符，数据库密码请使用随机字母数字。
3. 执行 `docker compose up --build -d`。
4. 本机浏览器打开 http://localhost:8000，用 `.env` 中管理员账号登录。
5. Users 页面创建 TM/TL（Requester）与 Infra Technician 账号。

首次启动自动创建数据库表和管理员；后续不会覆盖管理员密码。更改 `.env` 不会重设既有用户或数据库密码。

## 实现流程

| 状态 | 操作与责任人 |
|---|---|
| New | TM/TL 报修；Infra 收到站内通知 |
| In Progress | Infra 接受、指定技术人员，可调整严重程度 |
| Cancelled | Infra 拒绝新工单，必须填写原因 |
| Additional Information Requested | Infra 要求补充资料；双方用 Notes 沟通 |
| On Hold | Infra 暂停处理，必须填写原因 |
| Resolved, Pending Confirmation | Infra 填写 Resolution，通知报修人 |
| Closed | 报修人验证并填写关闭备注；或解决满 5 天自动关闭 |

五天按连续 120 小时计算；独立 scheduler 每分钟检查，网站读取工单时也补查。暂停可恢复处理。已关闭或取消的工单不可修改。SOP 的 Open 对应 New、Assigned 对应已指派的 In Progress、Resolved Verification Required 对应 Resolved, Pending Confirmation。

Requester 仅可见自己提交的工单。本版本不提供全团队共享可见性；Infra/Admin 可见全部工单。报修人可添加备注和确认关闭，Infra 不得代替报修人验证关闭。管理员创建账号。

## 功能

- 报修模板、地点、环境/Domain、严重程度与描述。
- 工单搜索、状态过滤、处理数量概览。
- 分派技术人员、备注、状态历史、解决说明。
- Work Logs 记录工作分钟数；首次增加日志记录 First Response 时间。
- 站内通知（新增、更新、解决、自动关闭）。无邮件发送。
- CSV 月报：按创建月份（UTC）筛选，包含响应时间、解决时间、工作分钟数。
- 界面时间显示 Singapore，数据库和 CSV 使用 UTC。
- 密码 scrypt 哈希、服务端可撤销会话、HttpOnly Cookie、角色及工单归属检查、写操作来源标头校验、CSV 公式转义。

模板、地点和 Domain 是初始选项，可在 `app/static/index.html` 修改。没有截图附件上传、SSO、邮件/短信、SLA 工作时间计算、批量分派、密码重置或审批功能。

## 正式环境

本交付没有部署到外部服务器。`compose.yaml` 仅绑定本机 127.0.0.1:8000。供同事使用时，在 HTTPS 反向代理后运行，配置 `COOKIE_SECURE=true`，限制网络访问，并定期备份 MySQL volume。登录限速应由反向代理配置。需要密码找回、离职账号停用、企业 SSO 时，应在正式上线前补齐。没有内置默认测试用户和测试工单。

查看日志：`docker compose logs web scheduler`。停止：`docker compose down`（保留数据库）。勿执行 `down -v`，它会删除数据库卷。

## 测试

```
python -m pip install -r requirements.txt
python -m pip install pytest==8.3.5 httpx==0.28.1
python -m pytest -q
```

默认使用临时 SQLite 验证 API 流程；设置 `TEST_DATABASE_URL` 可对独立、空白的测试 MySQL 数据库运行同一套测试。不要连接业务数据库，测试会创建账号和工单。MySQL 连接由 PyMySQL 提供。实际测试结果见 `VALIDATION.md`。

## 项目结构

- `app/main.py`：数据库模型、认证、权限、工单流程、通知与 CSV API。
- `app/scheduler.py`：五天自动关闭定时任务。
- `app/static/`：登录、工单列表、报修表单、详情和管理页面。
- `tests/test_workflow.py`：权限、状态流转与自动关闭测试。
- `compose.yaml` / `Dockerfile`：Web + MySQL + 定时任务部署。

数据库 schema 在 `main.py` 定义，首次创建表；本版本尚无历史 schema migration，后续改字段应加入迁移机制。
