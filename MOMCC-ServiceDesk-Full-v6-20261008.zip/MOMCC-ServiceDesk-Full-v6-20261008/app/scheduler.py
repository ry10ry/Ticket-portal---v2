"""Run separately: python -m app.scheduler. One worker per deployment."""
import time
import logging
from sqlalchemy.orm import Session
from app.main import engine, auto_close

logging.basicConfig(level=logging.INFO)
while True:
    try:
        with Session(engine) as session:
            count = auto_close(session)
            logging.info('Closed %s overdue tickets', count)
    except Exception:
        logging.exception('Auto-close failed; retrying next minute')
    time.sleep(60)
